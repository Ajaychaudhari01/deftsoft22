$(".incentive-slider").owlCarousel({
  loop: true,
  margin: 10,
  nav: true,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>",
  ],
  responsive: {
    0: {
      items: 1,
    },
    600: {
      items: 2,
    },
    1000: {
      items: 2,
    },
    1100: {
      items: 3,
    },
  },
});
$(".coming-soon").owlCarousel({
  loop: true,
  margin: 10,
  dots: false,
  nav: true,
  pullDrag: false,
  touchDrag: false,
  mouseDrag: false,
  // autoplay:true,
  // autoplaySpeed:300,
  items: 3,
  navText: [
    "<i class='fas fa-arrow-left'></i>",
    "<i class='fas fa-arrow-right'></i>",
  ],
  responsive: {
    0: {
      items: 1,
    },
    600: {
      items: 2,
    },
    1000: {
      items: 3,
    },
    1100: {
      items: 3,
    },
  },
});
// $('.in-slider').owlCarousel({
//     loop: true,
//     margin: 10,
//     dots: true,
//     nav: true,
//     navText: ["<i class='fas fa-arrow-left'></i>", "<i class='fas fa-arrow-right'></i>"],
//     responsive: {
//         0: {
//             items: 1
//         },
//         600: {
//             items: 1
//         },
//         1000: {
//             items: 1
//         }
//     }
// });
$(".in-slider").slick({
  dots: true,
  infinite: true,
  arrows: false,
  // autoplay: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  speed: 300,
});

// Development banner js
$(".dev-slider-for").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  nav: true,
  asNavFor: ".dev-slider-nav",
});
$(".dev-slider-nav").slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  asNavFor: ".dev-slider-for",
  //   dots: true,
  nav: true,
  focusOnSelect: true,
  prevArrow: '<div class="prev-button"><i class="fas fa-angle-left"></i></div>',
  nextArrow: '<div class="next-button"><i class="fas fa-angle-right"></i></div>',
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 3
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2
      }
    }
  ]
});


$(".dev-similar-slider").owlCarousel({
  loop: true,
  margin: 30,
  nav: false,
  dots: false,
  navText: [
    "<i class='fa fa-chevron-left'></i>",
    "<i class='fa fa-chevron-right'></i>",
  ],
  responsive: {
    0: {
      items: 1,
    },
    600: {
      items: 3,
    },
    1000: {
      items: 4.6,
      mergeFit: false
    }
  },
});