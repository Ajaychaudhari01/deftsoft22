<?php 


/* Template Name: Emi */


require_once 'config.php'; 

if (isset($_POST['submit']))
{
    $username=$_POST['username'];
    $email=$_POST['email'];


}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php bloginfo(
    "template_directory"
    ); ?>/css/style.css">
    <!-- Latest compiled and minified JavaScript -->
</head>
<body>
<header>
        <div class="container">
            <a href="#">Booking System Diary functions <span class="countdown bg-danger text-light"></span>
            </a>
        </div>
    </header>
    <div class="payment-form-sec comm-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 bg-light">                
                <form  method="POST" class="payment-form">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email Address</label>
                        <input type="email" class="form-control" value="<?php echo $email;?>" readonly name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Name</label>
                        <input type="text" class="form-control username" name="name"  placeholder="username" readonly value="<?php echo $username;?>">
                    </div>
                    
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Card Number</label>
                        <input type="text" class="form-control" name="card_number" id="cardNumber" placeholder="card number">
                    </div>
                    
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Card Month</label>
                        <input type="text" class="form-control" name="card_exp_month" id="cardExp" placeholder="card exp month">
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Card Year</label>
                        <input type="text" class="form-control" name="card_exp_year" id="cardExpYear" placeholder="card exp year">
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Card Cvv </label>
                        <input type="text" class="form-control" name="card_cvc" id="cardCVC" placeholder="CVC">
                    </div>
                    
                    <button type="submit" class="btn_design btn" id="Payments">Submit</button>
                </form>
                
                
            <div id="response">

            </div>    
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
    </div>
    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
</footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 
<script>
// $(document).ready(function () {

//     $(document).on('click','#Payments',function (event) {
//         event.preventDefault();
//         let name = $(".username").val();
//         $.ajax({
//             type: "POST",
//             url: "../sami/",
//             data: {
//                 email:$("#email").val(),
//                 card_number:$("#cardNumber").val(),
//                 card_exp_month:$("#cardExp").val(),
//                 card_exp_year:$("#cardExpYear").val(),
//                 card_cvc:$("#cardCVC").val(),           
//             },
            
//             success: function(data, textStatus, xhr) {
//             if (xhr.status == 200) 
//                 alert(data.Status);
//             console.log("hello");
//                 console.log("======>",data.Status);
//                 // $("#response").html(result);
//                 // window.location.href = "http://localhost/wordpress/checkout/";

//                 // console.log(result);
//             }
//         });
//     }); 
// });
</script>   
</body>
</html>