<?php  

/* Template Name: destroySession */

    session_start();
    $_SESSION['fname'] = "";
    $_SESSION['email'] = "";  
    $_SESSION['card_number'] = "";
    $_SESSION['card_exp_month'] = "";
    $_SESSION['card_exp_year'] = "";
    $_SESSION['card_cvc'] = "";
    session_unset();
    session_destroy();

    echo '<script>window.location.href="http://49.249.236.30:7000/wordpress/"</script>';   


?>