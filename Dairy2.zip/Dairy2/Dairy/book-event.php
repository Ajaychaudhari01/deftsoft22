<?php
?>

        
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dairy</title>
          <link rel="icon" type="image/png" href="css/fav.png" sizes="32x32" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="css/style.css">
        
</head>
<body id="bookEvent">
 

  <div class="cstm_loader" id="Loader">
    <div class="spinner-border text-light" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>
    <header>
        <div class="container">
      <a href="javascript:void(0);" id="HomeReturn" data-toggle="modal" data-target="#exampleModal">Booking System Diary Functions <span class="countdown bg-danger text-light"></span>
            </a>
        </div>
    </header>
    <!-- Button trigger modal -->
    
    <div id="Step1" class="comm-padding">
      <div class="container">
            
        <p>Please Select Your Event</p>
        <div class="quantity-sec">
        <div id="qtyError">
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <span id="qtyErr"></span>

          </div>
        </div>
            <div id="field1">Quantity
              <div class="quantity-btn">
                <button type="button" id="sub" class="sub">-</button>
                <input type="number" id="QtyValue" value="1" min="1" max="10" readonly />
                <button type="button" id="add" class="add">+</button>
                </div>
            </div>
        </div>
        <div class="available_Book_type_sec">
            <!-- <button type="button" id="getBookingDates" class="btn btn-info">Info</button> -->
            <div class="available_Book_type">
                <!--available_Book_type will be display here !!!! -->
                
            </div>
        </div>
        <div class="select-a-date-sec mt-5">
              <div id="dateErrors">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <span id="dateErrs"></span>
                </div>
              </div>
            <input class="flatpickr" placeholder="Please select a date">
            <p id="fromTodate" class="d-lg-none">You Have Selected Date - <small id="fromTime"></small> To <small id="toTime"></small></p>
            <p class="date_selection_message"></p>
        </div>
        <div id="ErrorMsg">
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <span id="getDateErro"></span>
          </div>
        </div>

        <button id="getDates" class="btn_design btn">Get Slots</button>   
      </div>
    </div>
    
    <!-- action="../checkout/" -->
  <div id="Step2">
    <form name="myForm"  enctype="multipart/form-data" method="post" id="myForm">
        <section class="event_booking_page">
            <div class="container">
              <p id="createDate" hidden></p>
                 <div id="ErrorMsgs">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <span id="getDateError"></span>
                    </div>
                  </div>
                
                  <div id="dateSelectionError">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <span id="dateSelectionErr"></span>
                    </div>
                  </div>

                  <div id="noDataError">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <span id="noDataErr"></span>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                  </div>
                <div class="cal-modal">
                    <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Select a date and time for your event</h2>
                    <p class="date_selection_message"></p>
                    <div id="calendar">
                        <div class="placeholder"> </div>
                    </div>
                </div>
                <div class="available_time_slot" id="DayDisplay">
                    <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Available times for <span id="selectedDtaes" class="text-danger"></span>  at your event</h2>
                    
                    <div class="select_time_slot" id="hello">
                        <!-- time slot will be display here !!!! -->
                    </div>
                    <div class="time_remember" id="Remember">
                        <p class="m-0"><b>Remember:</b> You will need to arrive no later than <span id="arrivalTim"  hidden="hidden"  name="arrivalTim">10:00</span><span id="arrivalTimer" name="dateandTime" class="font-weight-bold"></span></p>
                    </div>

                </div>
    
          <div class="text-right d-flex justify-content-between flex-wrap mt-2">
            <button class="btn_design back_btn btn mr-3" type="button" onclick="BackStep1()">Back</button>
            <button type="button" class="btn_design btn ml-5" name="submit" id="BookNOW">Proceed</button>
          </div>
            </div>
        </section>
    </form>

  </div>



<!-- ===============================   checkout section            ============================================== -->

    <section class="checkout_page" id="Step3">
        <div class="container">
            <h2 class="mt-0 mb-2 mb-md-4 font-weight-bold">CHECKOUT</h2>
            <div class="booking_details">
                <h3 class="mt-0 mb-2">YOUR BOOKING FOR <span id="checkoutDate"></span> AT STOCKHOLM</h3>
                <P class="mt-0 mb-2 mb-md-3">Check-in time: <span class="chekoutDateWIthtime"></span></P>
                <ul class="booking_details_inr">
                    <li class="booking_title">
                        <h3>2 FLIGHT PACKAGE – <span id="flightType"></span></h3>
                        <p><b>Location:</b> Stockholm</p>
                    </li>
                    <li>
                        <p><b>Time: <span class="chekOutTime"></span></b></p>
                    </li>
                
                    <li>
                        <p><b>Quantity: <span class="checkoutQty"></span></b></p>
                    </li>
                    <li>
                        <p><b>Price: <span>695.00Kr</span></b></p>
                    </li>
                </ul>
                <div class="time_remaining d-sm-flex justify-content-between align-items-center mt-3 mt-md-4 mb-1 mb-sm-2">
                    <p class="mb-2 mb-sm-0">Time remaining to complete this booking: <span id="demo">10:00</span> </p>
                    <h3 class="m-0">Total: 695.00Kr</h3>
                </div>
            </div>
          <form class="contact_form" action="../payment-2/" method="post" id="CheckoutForm">
            <div class="payment_details">
                <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">PLEASE ENTER YOUR BILLING AND PAYMENT DETAILS</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <h3 class="mt-0 mb-3">BILLING DETAILS</h3>
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" oncopy="return false" onpaste="return false" onkeypress="return /[a-zA-Z]/i.test(event.key)" id="" name="fname" onkeyup="nospaces(this)">
                            </div>
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" id="" name="lname" oncopy="return false" onpaste="return false" onkeypress="return /[a-zA-Z]/i.test(event.key)" onkeyup="nospaces(this)">
                            </div>
                            <div class="form-group">
                                <label>Telephone</label>
                                <input type="number" class="form-control" id="" name="telNumber" onkeyup="nospaces(this)">
                            </div>
                            <input type="text" class="form-control" id="sessionIds" name="sessionIds" hidden >

                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" id="" name="email" onkeyup="nospaces(this)">
                            </div>
                    </div>
                    <div class="col-lg-6">
                            <div class="form-group form-check">
                              <div class="checkbox-wrapper">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1" name="confirmation">
                                <label class="form-check-label" for="exampleCheck1">I understand that I need to arrive
                                    by <span id="arrivaltimes" class="font-weight-bold"></span> in order to take part in my first activity</label>
                                </div>
                            </div>
                            <div class="form-group form-check">
                              <div class="checkbox-wrapper">
                                <input type="checkbox" class="form-check-input" id="exampleCheck2" name="conditions">
                                <label class="form-check-label" for="exampleCheck2">I have read and agree to the <a
                                        href="#">terms and conditions</a></label>
                                </div>
                            </div>
                    </div>
                </div>
                    <div class="text-right d-flex justify-content-between mt-2">
                        <!-- <a class="btn_design back_btn btn mr-3" href="home.html">Back</a> -->
                        <button class="btn_design back_btn btn mr-3" type="button" onclick="BackStep2()">Back</button>
                        <button type="submit" class="btn_design btn ml-5" name="submit" id="CheckoutFormBtn">Payment</button>
                    </div>

               </form>

            </div>
        </div>
    </section>


<!-- Modal -->
<div class="modal fade cstm-modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to back home ??
      </div>
      <div class="modal-footer">
        <button type="button" class="btn_design btn" data-dismiss="modal" id="close">Yes</button>
        <button type="button" class="btn_design back_btn btn" data-dismiss="modal" aria-label="Close" id="save">No</button>
      </div>
    </div>
  </div>
</div>
    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
    </footer>
    
    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- for timer  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Validation link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="js/script.js"></script>

    
    <!-- for timer  -->
    <script>

              setTimeout(() => {
               $('.slot input[type=radio]').click(function() {
                  $('.slot').removeClass("checked");
                                  if ($(this).is(":checked")) {
                      $(this).parent().addClass("checked");
                  }
              });
             }, 1000); 


          $(document).on('click','#close',function (event) {
            var proceed = $("#close").text();
                  if (proceed) {
                    window.location.href = "http://49.249.236.30:7000/wordpress/";
                  }
                
          });

    function BackStep1(){
      $("#Step2").hide();
      $("#Step3").hide();
      $("#Step1").show();
    }

    function BackStep2(){
      $("#Step1").hide();
      $("#Step3").hide();
      $("#Step2").show();
    }


         

  jQuery('#Step2').css('opacity', '0');

jQuery('#Step3').css('opacity', '0');


    $(document).ready(function() {
    $("#Loader").show();
    $("#qtyError").hide();
    $("#dateErrors").hide();
    $("#ErrorMsgs").hide(); 
    $("#noDataError").hide();
     $("#Remember").hide();

      var arr = [];
      let counT = 0;      
    jQuery('#Loader').fadeOut(3000);
      SelectedBookingType();
      $("#getDates").on('click',function () {
        $("#Loader").show();
        let bookingintTypes= "";
        var value = $("input[type=radio][name=slot]:checked").val();
        if (value) {
          // alert('======='+value);
          bookingintTypes =value;
        }
        else {
          $("#Loader").hide();
          // alert('Nothing is selected');
        }
        let selBookingQty =  $('#QtyValue').val();
        let selBookingStartTime=$('#fromTime').text();
        $("#fromTOdate").html()
        let selBookingEndTime=$('#toTime').text();
        $("#selectdBookType").val(bookingintTypes);
        $("#flightType").text(bookingintTypes);
        $("#selectedQty").val(selBookingQty)
        $(".checkoutQty").text(selBookingQty); //3 api
        if(selBookingStartTime){
          $("#dateErrors").hide();
        }else{
          $("#dateErrors").show();
          $("#dateErrs").html("Please select date range ");
        }

          if(selBookingQty && bookingintTypes && selBookingStartTime){
          $("#ErrorMsg").hide();            
          if(selBookingEndTime){
            if (selBookingStartTime == selBookingEndTime)
            {
              var today = new Date(selBookingStartTime);
            var tomorrow = new Date(today);
            tomorrow.setDate(today.getDate()+1);
            console.log("===================tomorrow",tomorrow);
            selBookingEndTime=tomorrow.toISOString().slice(0, 10);
            console.log(selBookingEndTime);

            }
            arr = [selBookingQty,bookingintTypes,selBookingStartTime,selBookingEndTime];
            console.log(arr);
          }
          else{
            arr = [selBookingQty,bookingintTypes,selBookingStartTime,selBookingEndTime];
            console.log(arr);
          }
        }
        else{
          $("#Loader").hide();
          $("#getDateErro").html("Please select all fields");
          $("#ErrorMsg").show();          
          return 0;
        }
        console.log(arr);
        setTimeout(() => {
          $("#Step1").hide();
          $("#Step2").show();

  jQuery('#Step2').css('opacity', '1');

          $("#Loader").hide();
          CheckDate();
        });
      })
   

   //================================= create api 3 =======================================
   $("#BookNOW").on('click',function (){
    $("Step1").hide();
    $("#Step2").hide();
    $("#Loader").show();
    let selectedDateData =$("#selectedDtaes").text();
    let arrivalTimeData =$("#arrivalTimer").text();
    let selarrivalTimer=$('#arrivalTimer').text();
    // alert(selarrivalTimer);

    if (selectedDateData && arrivalTimeData ){
      $("#ErrorMsgs").hide(); 
      $("#arrivalTimer").html("");
    BookNow(); 
    $("#ErrorMsgs").hide(); 
    }
    else{
      $("#ErrorMsgs").show(); 
      $("#getDateError").html("Please select all fields !");
     $("#Loader").hide();
      $("#Step2").show();
      return 0; 
// http://enginetest.megafun.no/bookings/create?bookingTypeId=2&quantity=2&bookingDate=12022-08-04T13:00:00+01:00&sessionId=335137f2-e362-4aa5-ad16-03b98200f07f&unitCost=5&discountCode=null&vouchers=null

    }
    // if (selectedDateData){
    //   if(arrivalTimeData){
    //     $("#ErrorMsgs").hide(); 

    //   }
    //   else{
    //     $("#ErrorMsgs").show(); 
    //   $("#getDateError").html("Please select a time slot !");
    //   }
    // }
    // else{
    //   $("#ErrorMsgs").show(); 
    //   $("#getDateError").html("Please select a date !");
    // }
   })
   function BookNow() {
    timers(); //timer start
        let bookingDat=$("#createDate").text();
        // let bookingDat= "2022-08-04T13:00:00+01:00";
        let BookingQt=$(".checkoutQty").text();

        let BookingTypId =$("#flightType").text();
        console.log(BookingTypId);
        
        // let sessionId= "335137f2-e362-4aa5-ad16-03b98206j02g";
        let sessionId ="335137f2-e362-4aa5-ad16-03b98200f07f";
        // let sessionId ="cef0cbf3-6458-4f13-a418-ee4d7e";
        $("#sessionIds").val(sessionId);
        let url2 ='http://enginetest.megafun.no/bookings/create?bookingTypeId=1&quantity=5&"bookingDate"="2022-08-04T13:00:00+01:00"&"unitCost"=5&"discountCode"= ""&"vouchers"= null&sessionId=335137f2-e362-4aa5-ad16-03b98200f07f'
    let unitCost= 5;
    let url ='http://enginetest.megafun.no/bookings/create?bookingTypeId='+BookingTypId.trim()+'&quantity='+BookingQt+'&"bookingDate"="'+bookingDat+'"&sessionId='+sessionId+'&"unitCost"="'+unitCost+'"&"discountCode"="'+null+'"&"vouchers"="'+null;

        console.log(url);   
        $.ajax({
          url:url,
          type:'POST',
            success: function(data, textStatus, xhr) {
              console.log("=================>",data);
                if (xhr.status == 200) {

                $("#Step2").hide();
                $("#Step1").hide();
                $("#Step3").css('opacity','1');
                $("#Step3").show();
                $("#Loader").hide();
                }
                else{
                  // alert(1212);
                }
        console.log(xhr.status);
          }
        });
        
      } 




    
    //function for select a date 
    function CheckDate(){
      console.log('====',arr);
      let x =0;
      let chooseDate =0;
      $(".flatpickr-day").on('click', function(event){
        var noDateRange=1;
        $("#Loader").show();
        chooseDate =$(this).attr('aria-label');
        const elements = $('[aria-label]').css('background-color', '#eaeaea');
        var ele = $('[aria-label]').css('color','#000');   
        const elementss = $('[aria-label="'+chooseDate+'"]').css('background-color' ,'#b10794');
        const elementsss = $('[aria-label="'+chooseDate+'"]').css('color','#fff');        
        var dateWithDay = $(this).attr('aria-label');
        // console.log("date picker: ", dateWithDay);
        var xy = new Date(dateWithDay);
        // console.log("now====>",xy)
        var da = 60 * 60 * 24 * 1000;
        var xy = new Date(xy.getTime() + da);
        // console.log("hgfggh====================>",xy);
        // console.log("now2====>",xy)
        var dateWIthtime=(new Date(xy).toISOString());
        // console.log("dateWIthtime====>",dateWIthtime)
        $("#dateWIthtime").val(dateWIthtime);
        $(".chekoutDateWIthtime").text(dateWIthtime);
        let aj= "T00:00:00+01:00"
        const myJSON = JSON.stringify(xy);
        let y =myJSON.slice(1,11);
        const myDate = y.concat(aj);
        console.log("=====>>>>",myDate);
        $("#createDate").text(myDate);
        const dates = $(this).text(); 
        $('#selectedDtaes').text(dateWithDay);   
        $("#checkoutDate").text(dateWithDay); //api 3
        $('#selectedDates').val(myDate);                   
        $('#ChoosenDate').text(dateWithDay); 
        const dd = new Date(dateWithDay);
        dateWithDay= dd.toISOString();   
        let bookingSlot=[];
        let chosednSlots = [];
        let datess = [];
        let chosednTimeSlots=[];
        let uRL ='http://enginetest.megafun.no/diary/getdates/?BookingTypeId='+arr[1]+'&Quantity='+arr[0]+'&fromDate='+arr[2]+'&toDate='+arr[3];
        console.log("diary/getdates====>",uRL);
        // let url1 = 'http://enginetest.megafun.no/diary/getdates/?BookingTypeId=2&Quantity=9&fromDate=2022-07-22T12:05:19.640Z&toDate=2022-07-29T12:05:19.640Z';
        // // console.log(uRL);
        // // console.log(uRL);
        $.ajax({
          type:'POST',
          url:uRL,
          // url:uRL,
          success:function (data) {
            $("#Loader").hide();
            console.log("Check Dairyte ======>",data.dates);
            for(var i=0;i<data.dates.length;i++){
              bookingSlot[i] = (data.dates[i]);
              // console.log('APi Date = ', data.dates[i].date);
              // console.log('myDate = ', myDate);
              if (myDate==data.dates[i].date){
                noDateRange = 2;
                console.log("helo Chack +====>",data.dates[i].date);
              }
            }

           var rowss = [];
            let counT = 0;
    
          for(var j=0;j<bookingSlot.length;j++){
                  datess[j]=(bookingSlot[j].date);
                  let date =dateWithDay;

                  // console.log("====>>>>",dateWithDay);
                  if (myDate == datess[j])
                  {
                    console.log("myDate ==>", datess[j]);
                    counT = counT+1;
                    // console.log(bookingSlot[j].bookingSlots[j].fromTime);
                    for(var k=0;k<bookingSlot[j].bookingSlots.length;k++){
                      // console .log(k);
                     let slotTime =bookingSlot[j].bookingSlots[k].fromTime;
                      slotTime=slotTime.slice(11,16);

                      rowss +=  '<label class="slot"><span class="timeSlotss">'+slotTime+
                      '</span><input type="radio" class="SelectedBooking timeSlots"  value="' + bookingSlot[j].bookingSlots[k].fromTime +
                      '" name="slot" /></label>';
                    }
                    $('#hello').html(rowss); 
                  }
              // chosednSlots[j] =(bookingSlot[j].bookingSlots);
            }
            //============================================
            //for no date handling 

            //   if(noDateRange === 1){
            //                   $("#noDataError").show();
            //   $("#noDataErr").html("Sorry ! no event slot is available for this date");
            // }
            // else{
            //   $("#noDataError").hide();
            // }

            if(counT == 0){
              // alert("ohh!! no ! you have to selecte date between your range");
              $("#dateSelectionError").show();
              $("#dateSelectionErr").html("Sorry ! you have to select date between your range or no event is avialbale for today");
              $("#arrivalTimer").html("");

              $(".slot").hide();
              $("#DayDisplay").hide();
              $("#remember").hide();
            }
            else{
              $("#dateSelectionError").hide();
              $(".slot").show();
              $("#DayDisplay").show();
              $("#remember").show();
            }


              setTimeout(() => {
                SelectDate(); 
           
              }, 1000); 
            },
          })
        });
        
      }
      
//===============================================
//for next and prev button 
  $(".flatpickr-next-month").on('click', function(){
    setTimeout(CheckDate, 1000);
  });
  $(".flatpickr-prev-month").on('click', function(){
    setTimeout(CheckDate, 1000);
  });

  //==========================================




      //selected booking type ==>booking Type quantity and select date started
    function SelectedBookingType() {
      $('.add').click(function () {
        if ($(this).prev().val() < 5) {
          $(this).prev().val(+$(this).prev().val() + 1);
          $("#qtyError").hide();
        }
        else{
          $("#qtyError").show();
          $("#qtyErr").html("Quantity should not be more than 5");
        }
      });
      $('.sub').click(function () {
        if ($(this).next().val() > 1) {
          if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
          $("#qtyError").hide();
        }
        else{
          $("#qtyError").show();
          $("#qtyErr").html("Quantity should not be less than 1");

        }
      });
      $(".flatpickr").flatpickr({
        mode: "range",
        disableMobile: "true",
        altInput: true,
        altFormat: "Y-m-d ",
        dateFormat: "Y-m-d ",
        minDate:new Date().fp_incr(0),
        onClose: function(selectedDates, dateStr, instance) {
          var dateStart = instance.formatDate(selectedDates[0], "Y-m-d");
          var dateEnd = instance.formatDate(selectedDates[1], "Y-m-d");
          $('#fromTime').text(dateStart);
          $('#toTime').text(dateEnd);
          $(".date_selection_message").html("Date Range - <small>"+dateStart.split("T18:30:00.000Z")[0]+"</small> To <small>"+dateEnd.split("T18:30:00.000Z")[0]+"</small>");
        }
      });
      var rows = [];
      $.ajax({
        type:'GET',
        url:'http://enginetest.megafun.no/bookings/getbookingtypes',
        data:{
        },
        success:function (data) {
          for(var i=0;i<data.bookingTypes.length;i++){
            rows +=  '<label class="slot"><span class="bookingType SelectedBookingType">'+data.bookingTypes[i].description+
            '</span><input type="radio" class="SelectedBooking"  value="' + data.bookingTypes[i].id +
            '" name="slot" /></label>';
          };
          $('.available_Book_type').html(rows);
        },
      })     
    }
    
      function SelectDate() {
        $(".select_time_slot .slot .timeSlots").on('click',function () {
          $("#Remember").show();
              setTimeout(() => {
               $('.slot input[type=radio]').click(function() {
                  $('.slot').removeClass("checked");
                  if ($(this).is(":checked")) {
                      $(this).parent().addClass("checked");
                  }
              });
             },10 ); 
          let timeslots=$(this).val();
          // alert(timeslots);
         let end=timeslots.slice(11,16);
         console.log(end);
         
            var start = '0:45';
              s = start.split(':');
              e = end.split(':');
              min = e[1]-s[1];
              hour_carry = 0;
              if(min < 0){
                  min += 60;
                  hour_carry += 1;
              }
              hour = e[0]-s[0]-hour_carry;
              min = ((min/60)*100).toString()
              diff = hour + ":" + min.substring(0,2);
         $("#arrivalTimer").html(diff);
         $("#arrivaltimes").html(diff);
          // $(".chekOutTime").text(timeslots); //3 api
          // $("#selectedDates").val(timeslots);
          let userTimeSlots =timeslots.slice(11,16);
          // $(".chekOutTime").text(timeslots); //3 api
          $(".chekOutTime").text(userTimeSlots); //3 api
          $("#selectedDates").val(timeslots);
          $(".chekoutDateWIthtime").text(diff);


        });
      }
    
    });


//timer 
// ===============================
function timers() {
    $("#sessionVar").text()
    const d = new Date();
    let countDownDate = d.getTime();
    var x = setInterval(function() {
        var x= new Date().getTime();
        // change for time diffrendce
        var now = x-1800000;
        
        // var now = x-18000;
        var distance = countDownDate - now;
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
        if (distance < 0) {
            clearInterval(x);
            window.location.href = "http://49.249.236.30:7000/wordpress/";
            
            // document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
}

// Validation 
  //====================================================================
  // Custom Email
  //====================================================================
  $.validator.addMethod("customemail", 
  function(value, element) {
      return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);      
  },'Please enter a valid email.');

  $("#CheckoutForm").validate({
    rules: {
      fname : {
        required: true,
        minlength: 3
      },
      lname : {
        required: true,
        minlength: 3
      },
      email: {
        required: true,
        customemail: true
      },
      telNumber: {
        required: true,
        number: true,
        minlength:10,
        maxlength:12
      },
      confirmation: {
        required: true,
      },
      conditions: {
        required: true,
      }
    },
    messages : {
      fname: {
        minlength: "Name should be at least 3 characters"
      },
      lname: {
        minlength: "Name should be at least 3 characters"
      },
      email: {
        email: "Please enter a valid email address"
      },
      telNumber: {
        number: "Please enter a valid phone number"
      }
    },
    errorPlacement: function (error, element) {
      if (element.attr("type") === "checkbox") {
        error.insertAfter($(element).parent());
      }else{
        error.insertAfter(element);
      }
    },
  });

  //=================================
//function for space validation 
  //
      function nospaces(t){
  if(t.value.match(/\s/g)){
    t.value=t.value.replace(/\s/g,'');
  }
}
  $('#CheckoutFormBtn').click(function()
    {
      $("#Loader").show();
      setTimeout( function() {
        if($('#CheckoutForm').valid())
        {
          $('#CheckoutFormBtn').prop('disabled', true);
          $('#CheckoutForm').submit();
        } else {
          $("#Loader").hide();
          return false;
        }
      }, 1000);      
    });
      </script>
                                        
  </body>
</html>  
                                    
                                    
