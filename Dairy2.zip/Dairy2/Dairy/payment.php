<?php  

/* Template Name: payment */
if(isset($_POST['submit']))
{
}
 
else{
      header("Location: http://49.249.236.30:7000/wordpress/");
}



?>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Dairy</title>
        <link rel="icon" type="image/png" href="<?php bloginfo('template_directory')?>/css/fav.png" sizes="32x32" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/css/style.css">
  
</head>
<body id="bookEvent">
  	<div class="cstm_loader" id="Loader">
		<div class="spinner-border text-light" role="status">
		  <span class="sr-only">Loading...</span>
		</div>
	</div>
  <header>
    <div class="container">
      <a href="javascript:void(0);" id="HomeReturnBtn" data-toggle="modal" data-target="#exampleModal">Booking System Diary Functions <span class="countdown bg-danger text-light"></span>
      </a>
    </div>
  </header>


   <div class="container comm-padding" id="PaymentDiv">
            <div class="row" id="paymentDiv">
                <div class="col-md-3"></div>
                <div class="col-md-6">                
                    <form method="post" class="payment-form" id="PaymentForm">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email Address</label>
                            <input type="email" class="form-control" value="<?php 	echo $_POST['email']; ?>"  name="email" id="payemail" aria-describedby="emailHelp" readonly placeholder="Enter email">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">First Name</label>
                            <input type="text" class="form-control username" name="fname" id="payname" value="<?php 	echo $_POST['fname']; ?>" readonly placeholder="First name" >
                        </div>
                        
                           <div class="form-group">
                            <label for="exampleInputPassword1">Last Name</label>
                            <input type="text" class="form-control username" name="lname" id="lname" value="<?php 	echo $_POST['lname']; ?>" readonly placeholder="Last name" >
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Number</label>
                            <input type="number" oncopy="return false" onpaste="return false" class="form-control" name="card_number" id="cardNumber" placeholder="Card number">
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Month</label>
                            <input type="number" class="form-control" name="card_exp_month" id="cardExp" placeholder="Card expiry month MM">
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Year</label>
                            <input type="number" class="form-control" name="card_exp_year" id="cardExpYear" placeholder="Card expiry year YYYY">
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Card Cvv </label>
                            <input type="number" class="form-control" name="card_cvc" id="cardCVC" placeholder="CVV 123">
                        </div>
                        
                        <button type="submit" class="btn_design btn" id="PaymentFormBtn">Submit</button>
                    </form>   
                </div>
                <div class="col-md-3">
	             
	            </div>
            </div>
            
            <div>
                <div id="response"></div>
              
            </div>  
        </div>

    				 <div id="completNow">
	                  <button type="submit" class="btn_design btn"  name="submit" id="CompleteBook">Complete Now</button>
	                </div>

	                   	<!-- <p id="sessionIds" hidden><?php $_POST['sessionIds']; ?></p> -->
<!-- Modal -->

<!-- Modal -->
<div class="modal fade cstm-modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure to back home ??
      </div>
      <div class="modal-footer">
        <button type="button" class="btn_design btn" data-dismiss="modal" id="close">Yes</button>
        <button type="button" class="btn_design back_btn btn" data-dismiss="modal" aria-label="Close" id="save">No</button>
      </div>
    </div>
  </div>
</div>
  <footer>
    <div class="container">
      <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
    </div>
  </footer>
  
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	
	<!-- Validation link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

  <script src="<?php bloginfo('template_directory')?>/js/script.js"></script>
  <!-- for timer  -->
  <script type="text/javascript">
    // for home page alert
$(document).on('click','#close',function (event) {
  var proceed = $("#close").text();
        if (proceed) {
          window.location.href = "http://49.249.236.30:7000/wordpress/";
        }
      
});


  	$("#completNow").hide();
    $("#response").hide();
$(document).on('click','#PaymentFormBtn',function (event) {
	// Check validation
  	$("#Loader").show();
    if($('#PaymentForm').valid())
    {
      $('#PaymentFormBtn').prop('disabled', true);
    } else {
      $("#Loader").hide();
      return false;
    }

    // Call ajax
    event.preventDefault();
    $.ajax({
        type: 'POST',
      url: '<?php echo site_url(); ?>/sdk-php-master/semi.php/',
        data: {
        	name :$("#payname").val(),
            email:$("#payemail").val(),
            card_number:$("#cardNumber").val(),
            card_exp_month:$("#cardExp").val(),
            card_exp_year:$("#cardExpYear").val(),
            card_cvc:$("#cardCVC").val(),           
        },
        beforeSend: function() {
	        console.log('before');
	    },
        success: function(data, textStatus, xhr) {
        	$("#Loader").hide();
        	console.log('success');
            if (xhr.status == 200) {
            	$("#response").html(data); 
            	let compare =$("#PaymentStatus").text();
            	console.log("==================>",compare);
            	if(compare == "Your Payment has been Successful!")
            	{
            		$("#paymentDiv").hide();
                  setTimeout(() => {
                comelteBokk();
                      // $("#response").show();
                      $("#Loader").show();
                  });  
            		// $("#completNow").show();
            	}
              else{
                  $("#response").show();
                 $('#PaymentFormBtn').prop('disabled', false);
              }
            }
        },
        error: function (jqXHR, exception) {
        	$("#Loader").hide();
	        var msg = '';
	        if (jqXHR.status === 0) {
	            msg = 'Not connect.\n Verify Network.';
	        } else if (jqXHR.status == 404) {
	            msg = 'Requested page not found. [404]';
	        } else if (jqXHR.status == 500) {
	            msg = 'Internal Server Error [500].';
	        } else if (exception === 'parsererror') {
	            msg = 'Requested JSON parse failed.';
	        } else if (exception === 'timeout') {
	            msg = 'Time out error.';
	        } else if (exception === 'abort') {
	            msg = 'Ajax request aborted.';
	        } else {
	            msg = 'Uncaught Error.\n' + jqXHR.responseText;
	        }
	        console.log(msg);
	    },
       	
    });


});

//================================complte sales =====================
   // $("#CompleteBook").on('click',function (event) {
   //          event.preventDefault();
   function comelteBokk(){
            let FirstName=$("#payname").val();
            let LastName=$("#lname").val();
            let email=$("#payemail").val();
            let street = "random";
            let town = "heu";
            let postcode="305923";
            let amount = 25;
        let sessionId ="335137f2-e362-4aa5-ad16-03b98200f07f";
            // let sessionId =$("#sessionIds").text();
            console.log(sessionId);

        
            url2='http://enginetest.megafun.no/sales/complete?sessionId='+sessionId+'&firstName='+FirstName+'&lastName='+LastName+'&telephone='+null+
            '&email='+email+'&street='+street+'&town='+town+'&postcode='+postcode+'&paymentAmount='+amount+'&vendorTaxCode='+null+'&vpsTxId='+null+'&txAuthNo='+null+'&status='+ null;
            // const url1 ='http://enginetest.megafun.no/sales/complete/?SessionId='+sessionId+'&FirstName='+FirstName+'&LastName='+LastName+'&Email='+email;
            // console.log(url1); 
            // let url2 ="http://enginetest.megafun.no/sales/complete?sessionId=335137f2-e362-4aa5-ad16-03b98200f07f&firstName= Matt,&lastName= Development,&telephone= ,&email= matt@bookingsystem.com,&street= Random street,&town= Awesome town,&postcode= SH1 4BC,&paymentAmount= 25,&vendorTaxCode= ,&vpsTxId= ,&txAuthNo= ,&status=";
            console.log("url2===============>",url2);   
  
            $.ajax({
              type:'POST',
            url:url2,
              success:function (data, textStatus, xhr) {
                if (xhr.status == 200) {
                  // $("#response").show();
                  // $("#Loader").show();

                  setTimeout(() => {
                      $("#Loader").hide();
                      $("#response").show();
                      // window.location.href = "http://49.249.236.30:7000/wordpress/";
                  },2000); 

                     setTimeout(() => {
                       window.location.href = "http://49.249.236.30:7000/wordpress/";
                  },10000); 


            }
            else{
            	alert("error");
            }
               console.log(data);
              }
            });
     }   
// })

   	// Validation 
	//====================================================================
	// Custom Email
	//====================================================================
	$.validator.addMethod("customemail", 
	function(value, element) {
	    return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);      
  	},'Please enter a valid email.');

   	$("#PaymentForm").validate({
    rules: {
      fname : {
        required: true,
        minlength: 3
      },
      lname : {
        required: true,
        minlength: 3
      },
      email: {
        required: true,
        customemail: true
      },
      card_number: {
        required: true,
        number: true,
        minlength:15,
        maxlength:16
      },
      card_exp_month: {        
        required: true,
        number: true,
        minlength:2,
        maxlength:2,
        max:12
      },
      card_exp_year: {        
        required: true,
        number: true,
        minlength:4,
        maxlength:4
      },
      card_cvc: {        
        required: true,
        number: true,
        minlength:3,
        maxlength:3
      }
    },
    messages : {
      fname: {
        minlength: "Name should be at least 3 characters"
      },
      lname: {
        minlength: "Name should be at least 3 characters"
      },
      email: {
        email: "Please enter a valid email address"
      },
      card_number: {
        number: "Please enter a valid card number",
        minlength: "Please enter a valid card number",
        maxlength: "Please enter a valid card number",
      },
      card_exp_month: {
        number: "Please enter a valid card expiry month",
        minlength: "Please enter a valid card expiry month",
        maxlength: "Please enter a valid card expiry month",
        max: "Please enter a valid card expiry month",
      },
      card_exp_year: {
        number: "Please enter a valid card expiry year",
        minlength: "Please enter a valid card expiry year",
        maxlength: "Please enter a valid card expiry year",
      },
      card_cvc: {
        number: "Please enter a valid card cvv",
        minlength: "Please enter a valid card cvv",
        maxlength: "Please enter a valid card cvv",
      }
    },
    errorPlacement: function (error, element) {
      if (element.attr("type") === "checkbox") {
        error.insertAfter($(element).parent());
      }else{
        error.insertAfter(element);
      }
    },
  });

  </script>

