<?php 
// Product Details 
$itemName = "Demo Product";  
$itemNumber = "PN12345";  
$itemPrice = 25;  
$currency = "USD";  
 
// Authorize.Net API configuration  
define('ANET_API_LOGIN_ID', '6MDf9H98aU');  
define('ANET_TRANSACTION_KEY', '954w4b4s2MGuqYkZ');  
$ANET_ENV = 'SANDBOX'; // or PRODUCTION 
  
// Database configuration  
define('DB_HOST', 'localhost');  
define('DB_USERNAME', 'root');  
define('DB_PASSWORD', 'redhat');  
define('DB_NAME', 'project1');

?>


