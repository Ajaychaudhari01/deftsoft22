<?php
/* Template Name: Event */
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dairy</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="css/style.css" rel="stylesheet">

    
</head>
<body id="bookEvent">
    <header>
        <div class="container">
            <a href="#">Booking System Diary functions <span class="countdown bg-danger text-light"></span>
            </a>
        </div>
    </header>
    
    
    <div id="GetDatesSection" class="comm-padding">
      <div class="container">
            
        <p>Plsese Selected Your event</p>
        <div class="quantity-sec">
            <div id="field1">Quantity
                <button type="button" id="sub" class="sub">-</button>
                <input type="number" id="QtyValue" value="1" min="1" max="10" />
                <button type="button" id="add" class="add">+</button>
            </div>
        </div>
        <div class="available_Book_type_sec">
            <!-- <button type="button" id="getBookingDates" class="btn btn-info">Info</button> -->
            <div class="available_Book_type">
                <!--available_Book_type will be display here !!!! -->
                
            </div>
        </div>
        <div class="select-a-date-sec mt-5">
            <input class="flatpickr" placeholder="Plase select A date">
            <p>You Have Selected Date<small id="fromTime"></small> To <small id="toTime"></small></p>
        </div>
        <button id="getDates" class="btn_design btn">GetSlots</button>   
      </div>
    </div>
    
    
    <form name="myForm" action="../checkout/" enctype="multipart/form-data" method="post" id="myForm">
        <section class="event_booking_page">
            <div class="container">
                
                <div class="cal-modal">
                    <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Select a date and time for your event</h2>
                    <div id="calendar">
                        <div class="placeholder"> </div>
                    </div>
                </div>
                <div class="available_time_slot">
                    <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Available times for <span id="selectedDtaes" class="text-danger"></span>  at your event</h2>
                    
                    <div class="select_time_slot" id="hello">
                        <!-- time slot will be display here !!!! -->
                    </div>
                    <div class="time_remember">
                        <p class="m-0"><b>Remember:</b> You will need to arrive no later than <span id="arrivalTim"  hidden="hidden"  name="arrivalTim">10:00</span><span id="arrivalTimer" name="dateandTime" class="font-weight-bold">00:00</span></p>
                    </div>
                </div>
                
                
                
                <input type="text"   hidden="hidden" id="dateandTime" name="dateandTime">
                <input type="text"   hidden="hidden" id="selectedDates" name="selectedDates">
                <input type="text"   hidden="hidden" id="selectedQty" name="selectedQty">
                
                <input type="text"   hidden="hidden" id="selectdBookType" name="selectdBookType">
                <input type="text"   hidden="hidden" id="arrVal" name="arrVal">
                <input type="text"   hidden="hidden" id="dateWIthtime" name="dateWIthtime">

                
                
                
                
                <div class="text-right d-flex justify-content-between flex-wrap">
                    <a class="btn_design back_btn btn mr-3" href="http://localhost/wordpress/">Back</a>
                    <button type="submit" class="btn_design btn ml-5" name="submit" id="submit">Proceed</button>
                </div>
            </div>
        </section>
    </form>
    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
    </footer>
    
    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- for timer  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="js/script.js"></script>


    
    <!-- for timer  -->
    <script>
    $(document).ready(function() {
      var arr = [];
      $("#myForm").hide();
      SelectedBookingType();
      $("#getDates").on('click',function () {
        let bookingintTypes= "";
        var value = $("input[type=radio][name=slot]:checked").val();
        if (value) {
          // alert('======='+value);
          bookingintTypes =value;
        }
        else {
          alert('Nothing is selected');
        }
        let selBookingQty =  $('#QtyValue').val();
        let selBookingStartTime=$('#fromTime').text();
        let selBookingEndTime=$('#toTime').text();
        $("#selectdBookType").val(bookingintTypes);
        $("#selectedQty").val(selBookingQty)
        arr = [selBookingQty,bookingintTypes,selBookingStartTime,selBookingEndTime];
        console.log(arr);
        setTimeout(() => {
          $("#GetDatesSection").hide();
          $("#myForm").show();
          CheckDate();
        });
      })
   


    
    //function for select a date 
    function CheckDate(){
      console.log('====',arr);
      let x =0;
      $(".flatpickr-day").on('click', function(event){
        x=x+1;   
        // console.log(x);       
        
        $(".flatpickr-day .flatpickr-disabled").css('background-color', 'yellow');
        $(this).css('background-color', 'green');
        var dateWithDay = $(this).attr('aria-label');
        console.log("date picker: ", dateWithDay);
        var now = new Date(dateWithDay);
        var dateWIthtime=(new Date(now).toISOString());
        $("#dateWIthtime").val(dateWIthtime);
        let aj= "T00:00:00+01:00"
        const myJSON = JSON.stringify(now);
        let y =myJSON.slice(1,11);
        const myDate = y.concat(aj);
        console.log("=====>>>>",myDate);
        const dates = $(this).text(); 
        $('#selectedDtaes').text(dateWithDay);   
        $('#selectedDates').val(myDate);                   
        $('#ChoosenDate').text(dateWithDay); 
        const dd = new Date(dateWithDay);
        dateWithDay= dd.toISOString();   
        let bookingSlot=[];
        let chosednSlots = [];
        let datess = [];
        let chosednTimeSlots=[];
        let uRL ='http://enginetest.megafun.no/diary/getdates/?BookingTypeId='+arr[1]+'&Quantity='+arr[0]+'&fromDate='+arr[2]+'&toDate='+arr[3];
        console.log("+++++++",uRL);
        // let url1 = 'http://enginetest.megafun.no/diary/getdates/?BookingTypeId=2&Quantity=9&fromDate=2022-07-22T12:05:19.640Z&toDate=2022-07-29T12:05:19.640Z';
        // // console.log(uRL);
        // // console.log(uRL);
        $.ajax({
          type:'POST',
          url:uRL,
          // url:uRL,
          success:function (data) {
            console.log(data.dates);
            for(var i=0;i<data.dates.length;i++){
              bookingSlot[i] = (data.dates[i]);
            };
            var rowss = [];

          for(var j=0;j<bookingSlot.length;j++){
                  datess[j]=(bookingSlot[j].date);
                  let date =dateWithDay;
                  // console.log("====>>>>",dateWithDay);
                  if (myDate == datess[j])
                  {
                    // console.log(bookingSlot[j].bookingSlots[j].fromTime);
                    for(var k=0;k<bookingSlot[j].bookingSlots.length;k++){
                      // console .log(k);
                      // console.log(bookingSlot[j].bookingSlots[k].fromTime);
                      rowss +=  '<label class="slot"><span class="timeSlotss">'+bookingSlot[j].bookingSlots[k].fromTime+
                      '</span><input type="radio" class="SelectedBooking timeSlots"  value="' + bookingSlot[j].bookingSlots[k].fromTime +
                      '" name="slot" /></label>';
                    }
                    $('#hello').html(rowss); 
                  }
              // chosednSlots[j] =(bookingSlot[j].bookingSlots);
            }
              setTimeout(() => {
                SelectDate(); 
              }, 1000); 
            },
          })
        });
        
      }


      //selected booking type ==>booking Type quantity and select date started
    function SelectedBookingType() {
      $('.add').click(function () {
        if ($(this).prev().val() < 10) {
          $(this).prev().val(+$(this).prev().val() + 1);
        }
      });
      $('.sub').click(function () {
        if ($(this).next().val() > 1) {
          if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
        }
      });
      var aa=new Date().fp_incr(2);
      alert(aa)
      var date2= $(".flatpickr").flatpickr({
        mode: "range",
        disableMobile: "true",
        altInput: true,
        altFormat: "Z",
        dateFormat: "Z",
       // minDate: new Date().fp_incr(2),
        onClose: function(selectedDates, dateStr, instance) {
          var dateStart = selectedDates[1].toISOString();
          var dateEnd = instance.formatDate(selectedDates[2], "Z");
          $('#fromTime').text(dateStart);
          $('#toTime').text(dateEnd);
        }
      });

      //date2.set('maxDate', new Date(dateStr).fp_incr(-1));
      //alert(date2);

      var rows = [];
      $.ajax({
        type:'GET',
        url:'http://enginetest.megafun.no/bookings/getbookingtypes',
        data:{
        },
        success:function (data) {
          for(var i=0;i<data.bookingTypes.length;i++){
            rows +=  '<label class="slot"><span class="bookingType SelectedBookingType">'+data.bookingTypes[i].description+
            '</span><input type="radio" class="SelectedBooking"  value="' + data.bookingTypes[i].id +
            '" name="slot" /></label>';
          };
          $('.available_Book_type').html(rows);
        },
      })     
    }
    
      function SelectDate() {
        $(".select_time_slot .slot .timeSlotss").on('click',function () {
          let timeslots=$(this).text();
          // console.log(timeslots); 
          $("#arrivalTimer").html(timeslots);
          $("#selectedDates").val(timeslots);
        });
      }
    
    });
      </script>
                                        
  </body>
</html>  
                                    
                                    
