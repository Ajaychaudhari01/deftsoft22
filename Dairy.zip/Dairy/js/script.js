// generate events
var eventDates = {};
// var days= {};
// var booked = [1,4,7,8,12,13,25,28,30,45,78,34,49,53];
// for (var i =0;i<booked.length; i++){
//   // console.log(i);
//    days[i] = formatDate(new Date(new Date().setDate(new Date().getDate() + booked[i])));
// //  console.log(days[i]);
// //    eventDates[days[i]] += ["Annual Training Camp-II has been conducted in the campus"];

// }
// // console.log(booked.length);
// for (var j =0;j<booked.length; j++){
//     // console.log("hhdfh");
//     // console.log(days[j]);
//     eventDates[days[j]] = ["Annual Training Camp-II has been conducted in the campus"];
 
//  }
 
 
// // console.log(eventDates);
// let day3 = formatDate(new Date(new Date().setDate(new Date().getDate() + 0)));
// // console.log(day3);
// let day14 = formatDate(new Date(new Date().setDate(new Date().getDate() + 14)));
// let day19 =formatDate(new Date(new Date().setDate(new Date().getDate() + 19)));
// let day29 = formatDate(new Date(new Date().setDate(new Date().getDate() + 29)));
// let day34 = formatDate(new Date(new Date().setDate(new Date().getDate() + 34)));
// let day39 = formatDate(new Date(new Date().setDate(new Date().getDate() + 39)));
// let day28 =formatDate(new Date(new Date().setDate(new Date().getDate() + 28)));
// let day56 = formatDate(new Date(new Date().setDate(new Date().getDate() + 56)));
// eventDates[day3] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day14] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day19] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day28] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day29] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day34] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day39] = ["Annual Training Camp-II has been conducted in the campus"];
// eventDates[day56] = ["Annual Training Camp-II has been conducted in the campus"];
// // console.log(eventDates)

let day2 = formatDate(new Date(new Date().setDate(new Date().getDate() + 10)));
eventDates[day2] = ["End of Annual Training Camp-II"];
var maxDate = {
    1: new Date(new Date().setMonth(new Date().getMonth() + 11)),
    2: new Date(new Date().setMonth(new Date().getMonth() + 10)),
    3: new Date(new Date().setMonth(new Date().getMonth() + 9))
};

var flatpickr = $("#calendar .placeholder").flatpickr({
    inline: true,
    minDate: "today",
    maxDate: maxDate[3],
    
    showMonths: 1,
    // enable: ["2022-09-30", "2022-07-21", "2022-08-08", new Date(2022, 9, 9) ],
    enable :[],
    disableMobile: "true",
    onDayCreate: function (date, str, inst) {
        var contents = "";
        if (date.length) {
            for (i = 0; i < eventDates.length; i++) {
                contents +=
                    '<div class="event"><div class="date">' +
                    flatpickr.formatDate(date[0], "l J F") +
                    '</div><div class="location">' +
                    eventDates[str][i] +
                    "</div></div>";
            }
        }
        $("#calendar .calendar-events").html(contents);
    },
    locale: {
        weekdays: {
            shorthand: ["S", "M", "T", "W", "T", "F", "S"],
            longhand: [
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ]
        }
    }
});

eventCaledarResize($(window));
$(window).on("resize", function () {
    eventCaledarResize($(this));
});

function eventCaledarResize($el) {
    var width = $el.width();
    if (flatpickr.selectedDates.length) {
        flatpickr.clear();
    }
    if (width >= 992 && flatpickr.config.showMonths !== 3) {
        flatpickr.set("showMonths", 3);
        flatpickr.set("maxDate", maxDate[3]);
    }
    if (width < 992 && width >= 768 && flatpickr.config.showMonths !== 2) {
        flatpickr.set("showMonths", 2);
        flatpickr.set("maxDate", maxDate[2]);
    }
    if (width < 768 && flatpickr.config.showMonths !== 1) {
        flatpickr.set("showMonths", 1);
        flatpickr.set("maxDate", maxDate[1]);
        $(".flatpickr-calendar").css("width", "");
    }
}

function formatDate(date) {
    let d = date.getDate();
    let m = date.getMonth() + 1; //Month from 0 to 11
    let y = date.getFullYear();
    return "" + y + "-" + (m <= 9 ? "0" + m : m) + "-" + (d <= 9 ? "0" + d : d);
}
